// declaring new variables
var date = new Date();
var hour = date.getHours();
// demonstrating the if statement
if (hour >= 22 || hour <= 5) 
  document.write("Goodnight, world!");
else
  document.write("Hello, world!");
