<?php
// Set up some feeds
$feeds = array ('0' => array('title' => 'CNN Technology', 
                             'feed' => 'http://rss.cnn.com/rss/cnn_tech.rss'),
                '1' => array('title' => 'BBC News', 
                             'feed' => 
'http://news.bbc.co.uk/rss/newsonline_uk_edition/front_page/rss.xml'),
                '2' => array('title' => 'Wired News', 
                             'feed' => 
'http://wirednews.com/news/feeds/rss2/0,2610,3,00.xml'));
?>
